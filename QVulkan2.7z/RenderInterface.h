#pragma once

#include <QVulkanWindow>

struct IVulkanRenderer
    : public QVulkanWindowRenderer
{
    static std::unique_ptr<IVulkanRenderer> Create(QVulkanWindow& window);

    virtual void HandleMouseMove(int32_t x, int32_t y, const Qt::MouseButtons& buttons) = 0;

    ~IVulkanRenderer() override = default;
};
